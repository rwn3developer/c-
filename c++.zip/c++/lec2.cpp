#include<iostream>
using namespace std;
int sum(int a,int b);
int min(int a,int b);
int main()
{
	//udf 
	//return with no perameter
	int a=10,b=5;
	int ans = sum(a,b);
	int minn = min(a,b);
	cout<<"Ans = "<<ans;
	cout<<"Ans = "<<minn;

}

inline int sum(int a,int b)
{
	int c = a + b;
	return c;
}

int min(int a,int b)
{
	int c = a - b;
	return c;
}
