//ARRAY OF Structure (Group of member)

#include<stdio.h>

struct abc
{
	int a;
	float b;
}a1;

union xyz
{
	int a;
	float g;
}x1;

main()
{
	printf("structure size of is := %d\n",sizeof(a1));
	printf("union size of is := %d\n",sizeof(x1));
}

