//udf (arguments and no return value using pointer)

//call by value (not use pointer)
//call by reference (using pointer)

#include<stdio.h>
main()
{
	int i,arr[10];
	int *pt[10];
	
	for(i=0;i<5;i++)
	{
		printf("enter the array value :=");
		scanf("%d",&arr[i]);
		
		pt[i]=&arr[i];
	}
	
	
	for(i=0;i<5;i++)
	{
		printf("%x\n",pt[i]);
	}
	
	for(i=0;i<5;i++)
	{
		printf("%d\n",*pt[i]);
	}	
	
}
