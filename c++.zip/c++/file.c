//File Handling
//File Mode ( write(w),read(r),append(a))

#include<stdio.h>
main()
{
	FILE *fp;
	int no;
	char name[90];
	
	fp=fopen("abc.txt","w");
	
	if(fp==NULL)
	{
		printf("error..!!");
	}
	
	printf("Enter the Number :=");
	scanf("%d",&no);
	
	printf("Enter the Name :=");
	scanf("%s",&name);
	
	printf("Your Number is := %d\n",no);
	printf("Your Name is := %s\n",name);
	
	fprintf(fp,"Your Number is := %d\n",no);
	
	fprintf(fp,"Your Name is := %s\n",name);
}
