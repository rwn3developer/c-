#include<iostream>
using namespace std;

class Demo{
	public:
		int a,b;
		void data()
		{
			cout<<"Enter no A : ";
			cin>>a;
			cout<<"Enter no B : ";
			cin>>b;
		}
		
		void sum()
		{
			int c;
			c= a + b;
			cout<<"Sum = "<<c<<endl;
		}
		
		void sub()
		{
			int c;
			c = a-b;
			cout<<"Sub = "<<c<<endl;
		}
};

int main()
{
	Demo d;
	d.data();
	d.sum();
	d.sub();
}
