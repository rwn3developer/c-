#include<iostream>
using namespace std;

int sum(int a,int b);
int main()
{
	int ans;
//	simple function
//	no return with perameter
//	return with no perameter
//	return with perameter
	ans = sum(5,5);
	cout<<"Ans = "<<ans;

	
	
}

inline int sum(int a,int b)
{
	int c = a + b;
	return c;
}
